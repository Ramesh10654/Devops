import "./styles.css";

import { Desktop8 } from "./Desktop8/Desktop8";

export default function App() {
return (
    <div>
    <Desktop8 />
    </div>
);
}
